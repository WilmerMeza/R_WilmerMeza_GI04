export class UnitModel{
    id: number = 0 ;
    name: string = '';
    director : string = '';
    telephone : string = '';
    address : string = '';
    department : string = '';
    active : string = '';
}